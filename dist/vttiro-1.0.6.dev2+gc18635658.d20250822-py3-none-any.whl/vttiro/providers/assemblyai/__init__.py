# this_file: src/vttiro/providers/assemblyai/__init__.py
"""AssemblyAI transcription provider."""

from .transcriber import AssemblyAITranscriber

__all__ = ["AssemblyAITranscriber"]